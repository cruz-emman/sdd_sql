const connection = require('../../DB/db.js');


const login = async (req,res) =>{
    const {user_number, user_password, user_category} = req.body;
    if(!user_number || !user_password || !user_category) return res.status(400).json({error: "Please Enter User Number and Password"});

    
    try {
        const conn = await connection;
        const [rows,fields] = await conn.execute('SELECT * FROM users WHERE user_number = ? AND user_password = ? AND user_category = ?', [user_number, user_password, user_category])
        
        if(rows.length === 0)
            return res.status(401).json({error: 'Invalid username or password'})
        
            const user = {...rows[0]}
            delete user.user_password;
            res.status(200).json(user);

        console.log(user)
    } catch (error) {
        console.log(user)

        console.error(error.message)
        res.status(500).json({ error: error.message })
    }
}

module.exports = {login}