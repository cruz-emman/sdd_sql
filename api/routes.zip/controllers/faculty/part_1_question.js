const connection = require('../../DB/db.js');

 const addQuestion1 = async (req, res) => {
    const { question, question_order, type, toggle, tableName } = req.body;
    const query = `INSERT INTO facultyquestionpart1 (question, question_order, type,toggle) VALUES (?,?,?,?)`;
    
 try {
      const conn = await connection.getConnection();
      const [rows, field] = await conn.execute(query, [
        question,
        question_order,
        type,
        toggle
      ]);
      conn.release(); // release the connection back to the pool
      res.status(200).json(rows);
    } catch (error) {
      if (conn) {
        conn.release(); // release the connection back to the pool in case of an error
      }
      res.status(402).json(error);
      console.log(error);

    }
  }



  const getQuestion1 = async (req,res) =>{
      const query = "SELECT * FROM facultyquestionpart1"

        try {
      const conn = await connection.getConnection(); // get a connection from the pool
      const [rows, fields] = await conn.execute(query);
      conn.release(); // release the connection back to the pool
      res.status(200).json(rows);
    } catch (error) {
      if (conn) {
        conn.release(); // release the connection back to the pool in case of an error
      }
      res.status(402).json(error);
      console.log(error);
    }
  }


 const getSingleQuestion1 = async (req,res ) =>{

  const query = "SELECT * FROM facultyquestionpart1 WHERE idfacultyquestionpart1 = ?"
  const id = req.params.id
 try {
    const conn = await connection.getConnection();
    const [rows, field] = await conn.execute(query, [id])
    conn.release(); // release the connection back to the pool
    res.status(200).json(rows[0])

  } catch (error) {
    if (conn) {
      conn.release(); // release the connection back to the pool in case of an error
    }
    res.status(402).json(error);
    console.log(error);
  }
  
}


 const updateQuestion1 = async (req,res) =>{
  const id = req.params.id;
  const q = "UPDATE facultyquestionpart1 SET `question`=?, `question_order` = ?, `type` = ?, `toggle`=? WHERE `idfacultyquestionpart1` = ?"

  const values = [req.body.question, req.body.question_order, req.body.type, req.body.toggle]

    try {
      const conn = await connection.getConnection();

      await conn.execute(q, [...values, id  ], (err, data) => {
        if (err) return res.status(500).json("err", err.message);
        conn.release(); // release the connection back to the pool

        res.status(200).json(data)
      });
    } catch (error) {
      if (conn) {
        conn.release(); // release the connection back to the pool in case of an error
      }
      res.status(402).json(error);
      console.log(error);
    }
}

 const deleteQuestion1 = async (req,res) =>{
  const id = req.params.id;
  const q = "DELETE FROM facultyquestionpart1 WHERE `idfacultyquestionpart1` = ? "

  try {
    const conn = await connection.getConnection();
    const [rows, field] = await conn.execute(q, [id])
    conn.release(); // release the connection back to the pool
    res.status(200).json(rows)
  } catch (error) {
    if (conn) {
      conn.release(); // release the connection back to the pool in case of an error
    }
    res.status(402).json(error);
    console.log(error);
  }

}

const getQuestionType = async (req,res ) =>{

  const query = "SELECT * FROM facultyquestionpart1 WHERE question_order = ?"
  const id = req.params.id
  try {
    const conn = await connection.getConnection();
    const [rows, field] = await conn.execute(query, [id])
    res.status(200).json(rows[0])
  } catch (error) {
    if (conn) {
      conn.release(); // release the connection back to the pool in case of an error
    }
    res.status(402).json(error);
    console.log(error);
  }
  
}

module.exports = {addQuestion1, getQuestion1, getSingleQuestion1 , updateQuestion1 ,deleteQuestion1, getQuestionType}