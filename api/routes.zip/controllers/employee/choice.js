const connection = require('../../DB/db.js');


 const addChoice = async (req,res) =>{
    const {question_id, question_choices, toggle, part, question_name} = req.body
    const q = "INSERT INTO employeeschoices (`question_id`, `question_choices`, `toggle`, `part`, `question_name`) VALUES (?,?,?,?,?)"
   
    try {
      const conn = await connection.getConnection();
      const [rows, fields] = await conn.execute(q,[
        question_id, question_choices, toggle, part,question_name
    ] )
    conn.release(); // release the connection back to the pool

        res.status(200).json(rows)

    } catch (error) {
      if (conn) {
        conn.release(); // release the connection back to the pool in case of an error
      }
      res.status(402).json(error);
      console.log(error);

    }
}

 const getChoices = async (req,res) =>{
    const id = req.params.id;
    const part = req.query.part;
    
    const q = "SELECT * FROM employeeschoices WHERE question_id = ? && part = ?";
    

    try {
      const conn = await connection.getConnection();
      const [rows, fields] = await conn.execute(q, [id,part]);
      conn.release(); // release the connection back to the pool

      res.status(200).json(rows);
    } catch (error) {
      if (conn) {
        conn.release(); // release the connection back to the pool in case of an error
      }
      res.status(402).json(error);
      console.log(error);
    }
    
}


const getAllChoices = async (req,res) =>{
  const q = "SELECT * FROM employeeschoices"
  try {
    const conn = await connection.getConnection();
    const [rows, fields] = await conn.execute(q);
    conn.release(); // release the connection back to the pool

    res.status(200).json(rows);
  } catch (error) {
    if (conn) {
      conn.release(); // release the connection back to the pool in case of an error
    }
    res.status(402).json(error);
    console.log(error);
  }

}


 const deleteChoices = async (req,res) =>{
    const id = req.params.id;
    const q = "DELETE FROM employeeschoices WHERE `idemployeesChoices` = ?  " 
  
    try {
      const conn = await connection.getConnection();
      const [rows, field] = await conn.execute(q, [id])
      conn.release(); // release the connection back to the pool

      res.status(200).json(rows)
      
  
    } catch (error) {
      if (conn) {
        conn.release(); // release the connection back to the pool in case of an error
      }
      res.status(402).json(error);
      console.log(error);
    }
  
  }

  const getChoicesForUI = async(req,res) =>{
    const name = req.query.name;
    const part = req.query.part;
    
    const q = "SELECT * FROM employeeschoices WHERE `question_name` = ? AND `part` = ?";
    

    try {
      const conn = await connection.getConnection();
      const [rows, fields] = await conn.execute(q, [name,part]);
      conn.release(); // release the connection back to the pool

      res.status(200).json(rows);
    } catch (error) {
      if (conn) {
        conn.release(); // release the connection back to the pool in case of an error
      }
      res.status(402).json(error);
      console.log(error);    }
  }

  module.exports = {deleteChoices, getChoices, addChoice, getAllChoices, getChoicesForUI}