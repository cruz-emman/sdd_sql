const connection = require('../../DB/db.js');

const addResult = async (req,res) =>{
    const {user_number,user_category, choice} = req.body
    const query = "INSERT INTO results (user_number, user_category, choice) VALUES (?,?,?)"
    try {
        const conn = await connection.getConnection();
        const [rows, field] = await conn.execute(query,[
            user_number,
            user_category,
            choice,

        ])
        conn.release();
        res.status(200).json("Added Successfuly")
    } catch (error) {
        console.log(error)
    }
}

const getResults = async (req,res) =>{
    const query = "SELECT * FROM results"

    try {
        const conn = await connection.getConnection();

        const [rows, field] = await conn.execute(query)
        conn.release();
        res.status(200).json(rows)
    } catch (error) {
        res.status(400).json(error)
    }
}

module.exports = {addResult, getResults}